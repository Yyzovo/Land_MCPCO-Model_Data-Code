function weights = CV_weight(X)

std_dev = std(X, 0, 1);  
mean_val = mean(X, 1);  

cv = std_dev ./ mean_val; 

weights = cv / sum(cv);  

end