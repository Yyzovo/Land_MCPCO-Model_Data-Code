function output_01 = ObjFuc_01(Index)

global Info_Resident
global DisMt

Total_MinDistance = 0;

for i = 1:length(Info_Resident)
    if ~ismember(Info_Resident(i,1), Index)
        MinDistance = 1000000;
        for j = 1:length(Index)
            if DisMt(Info_Resident(i,1),Index(j))<MinDistance
                MinDistance = DisMt(Info_Resident(i,1),Index(j));
            end
        end
        Total_MinDistance = Total_MinDistance+MinDistance;
    end
end

output_01 = Total_MinDistance/(length(Info_Resident)-length(Index));

end