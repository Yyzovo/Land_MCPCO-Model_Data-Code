function [output] = ObjFuc_All(Index)

Obj1 = ObjFuc_01(Index);
Obj2 = ObjFuc_02(Index);
Obj3 = ObjFuc_03(Index);
Obj4 = ObjFuc_04(Index);
Obj5 = ObjFuc_05(Index);
Obj6 = ObjFuc_06(Index);
Obj7 = ObjFuc_07(Index);
Obj8 = ObjFuc_08(Index);

Obj = [Obj1,Obj2,Obj3,Obj4,Obj5,Obj6,Obj7,Obj8];
max_Obj = [120.6351,242.9653,41,42,8,404.75,12,384.0833];
min_Obj = [57.6757,105.7039,20,27,4,172.5,0,185.8333];
weight_Obj = [0.1825,0.1744,0.0735,0.0686,0.1150,0.0982,0.2207,0.0672];

for i = 1:8
    Obj(i) = (Obj(i)-min_Obj(i))/(max_Obj(i)-min_Obj(i));
end

Obj(7) = 1-Obj(7);

output = weight_Obj*Obj';

end