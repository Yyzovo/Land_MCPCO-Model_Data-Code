function [mutated] = MutationFuc(child,mutaionMeanRate)

global ParalCombineMatrix
global lenGene
lenPCM = length(ParalCombineMatrix);
mutated = zeros(1,lenGene);

newPCM=zeros(lenPCM,5);
newPCM(1,1:3)=[1,ParalCombineMatrix(1,1),ParalCombineMatrix(1,2)];
for i=2:lenPCM
    newPCM(i,1) = 1+sum(ParalCombineMatrix(1:i-1,1));
    newPCM(i,2) = newPCM(i,1)+ParalCombineMatrix(i,1)-1;
    newPCM(i,3) = ParalCombineMatrix(i,2);
end

for i=1:lenPCM
    C_n=ParalCombineMatrix(i,1);
    C_k=ParalCombineMatrix(i,2);
    newPCM(i,4) = log(cc(C_n,C_k));
end

for i=1:lenPCM
    newPCM(i,5) = newPCM(i,4)/sum(newPCM(:,4));
end

for i=1:lenPCM
    mutationRate = mutaionMeanRate*lenPCM*newPCM(i,5);
    geneSeg = child(newPCM(i,1):newPCM(i,2));
    if rand < mutationRate
        onesPos = find(geneSeg);
        zerosPos = find(~geneSeg);
        if ~isempty(onesPos) && ~isempty(zerosPos)
            swap1 = onesPos(randi(length(onesPos)));
            swap0 = zerosPos(randi(length(zerosPos)));
            geneSeg(swap1) = 0;
            geneSeg(swap0) = 1;
        end
    end
    mutated(newPCM(i,1):newPCM(i,2))=geneSeg;
end

end