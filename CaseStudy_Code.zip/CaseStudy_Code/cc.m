function [out] = cc(n,m)
out=factorial(n)/(factorial(m)*factorial(n-m));
end