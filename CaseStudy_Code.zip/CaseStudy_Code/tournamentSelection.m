function [selectedIndex] = tournamentSelection(fitness, numSelections, tournamentSize)

selectedIndex = zeros(numSelections, 1);
for i = 1:numSelections
    candidates = randperm(length(fitness), tournamentSize);
    [~, idx] = min(fitness(candidates)); 
    selectedIndex(i) = candidates(idx); 
end

end