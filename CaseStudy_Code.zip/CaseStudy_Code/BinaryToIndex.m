function [Selected_Index] = BinaryToIndex(Bi,n)

global ChoiceSet_History 
global ChoiceSet_Business
global ChoiceSet_Activity
global ChoiceSet_Mix

Selected_Index=zeros(1,22);
num=1;

for i=1:5
    if Bi(1,i)==1
        Selected_Index(1,num)=ChoiceSet_Mix(i);
        num=num+1;
    end
end

for i=6:14
    if Bi(1,i)==1
        Selected_Index(1,num)=ChoiceSet_History(i-5);
        num=num+1;
    end
end

for i=15:55
    if Bi(1,i)==1
        Selected_Index(1,num)=ChoiceSet_Business(i-14);
        num=num+1;
    end
end

Index_IsZero=find(Bi(1,1:5) == 0);
for i=56:60-n
    if Bi(1,i)==1
        Selected_Index(1,num)=ChoiceSet_Mix(Index_IsZero(i-55));
        num=num+1;
    end
end



for i=61-n:76-n
    if Bi(1,i)==1
        Selected_Index(1,num)=ChoiceSet_Activity(i-60+n);
        num=num+1;
    end
end


end