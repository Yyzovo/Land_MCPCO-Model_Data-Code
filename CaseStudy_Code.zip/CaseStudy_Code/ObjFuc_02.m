function output_02 = ObjFuc_02(Index)

global Info_Resident
global DisMt
global ChoiceSet_Activity

total_MinDistance = 0;
total_Resident = 0;
selected_Activity = Index(17:22);

for i = 1:length(Info_Resident)
    if ~ismember(Info_Resident(i,1), Index)
        MinDistance = 1000000;
        for j = 1:length(selected_Activity)
            if DisMt(Info_Resident(i,1),selected_Activity(j))<MinDistance
                MinDistance = DisMt(Info_Resident(i,1),selected_Activity(j));
            end
        end
        total_MinDistance = total_MinDistance+MinDistance*Info_Resident(i,2);
        total_Resident = total_Resident + Info_Resident(i,2);
    end
end

output_02 = total_MinDistance/total_Resident;

end