function [output03] = ObjFuc_03(Index)

global Info_PropertyRights
list = Index(1:16);

output03 = 0;
for i = 1:length(list)
    rowID = find(Info_PropertyRights(:,1)==list(i));
    output03 = output03 + Info_PropertyRights(rowID,2);
end

end