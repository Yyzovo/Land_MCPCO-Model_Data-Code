function [outVec] = Rand_FeasibleSolution_Binary(n)

outVec=zeros(1,76-n);

gene1 = randsample(5,n);
gene2 = randsample(9,4-n);
gene3 = randsample(46-n,12);
gene4 = randsample(16,6);

for i=1:n
    outVec(1,gene1(i))=1;
end

for i=1:4-n
    outVec(1,5+gene2(i))=1;
end

for i=1:12
    outVec(1,14+gene3(i))=1;
end

for i=1:6
    outVec(1,60-n+gene4(i))=1;
end

end