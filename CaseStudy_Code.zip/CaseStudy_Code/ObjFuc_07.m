function output_07 = ObjFuc_07(Index)

global Info_CommercialStreet 

list=Index(5:16);

output_07=0;

for i=1:length(list)
    output_07 = output_07 + ismember(list(i),Info_CommercialStreet);
end

end