function [output06] = ObjFuc_06(Index)

global DisMt
Index_temple = 135;
list = Index(1:4);

output06 = 0;
for i = 1:length(list)
    output06 = output06 + DisMt(Index_temple,list(i));
end

output06 = output06/4;

end