function [output04] = ObjFuc_04(Index)

global Info_DamageLevel
list = Index(1:16);

output04 = 0;
for i = 1:length(list)
    rowID = find(Info_DamageLevel(:,1)==list(i));
    output04 = output04 + Info_DamageLevel(rowID,2);
end

end