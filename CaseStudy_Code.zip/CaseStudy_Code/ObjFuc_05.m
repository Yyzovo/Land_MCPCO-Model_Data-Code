function [output05] = ObjFuc_05(Index)

global Info_History
list = Index(1:4);

output05 = 0;
for i = 1:length(list)
    rowID = find(Info_History(:,1)==list(i));
    output05 = output05 + Info_History(rowID,2);
end

end