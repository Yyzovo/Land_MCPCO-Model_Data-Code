function [output08] = ObjFuc_08(Index)

global DisMt
Index_temple = 135;
list = Index(5:16);

output08 = 0;
for i = 1:length(list)
    output08 = output08 + DisMt(Index_temple,list(i));
end

output08 = output08/12;

end