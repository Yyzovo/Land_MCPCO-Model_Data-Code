%% Optimization Function Testing, Data Normalization, and Objective Function Weight Calculation
clc,clear,close all
warning("off")

%% [1]Data Loading

%[1.1]
[num00 raw00]=xlsread("E:\CaseStudy\CaseStudy_00_Graph.xlsx");

%[1.2]
[num01 raw01]=xlsread("E:\CaseStudy\CaseStudy_01_ChoiceSet_History.xlsx");
[num02 raw02]=xlsread("E:\CaseStudy\CaseStudy_02_ChoiceSet_Business.xlsx");
[num03 raw03]=xlsread("E:\CaseStudy\CaseStudy_03_ChoiceSet_Activity.xlsx");
[num04 raw04]=xlsread("E:\CaseStudy\CaseStudy_04_ChoiceSet_Mix.xlsx");

%[1.3]
[num05 raw05]=xlsread("E:\CaseStudy\CaseStudy_05_Resident.xlsx");
[num06 raw06]=xlsread("E:\CaseStudy\CaseStudy_06_Tourist.xlsx");
[num07 raw07]=xlsread("E:\CaseStudy\CaseStudy_07_History.xlsx");
[num08 raw08]=xlsread("E:\CaseStudy\CaseStudy_08_Publicness.xlsx");
[num09 raw09]=xlsread("E:\CaseStudy\CaseStudy_09_DamageLevel.xlsx");
[num10 raw10]=xlsread("E:\CaseStudy\CaseStudy_10_CommercialStreet.xlsx");

%% [2]Variable Definition and Initialization

% [2.1]
global NumNeed_History
global NumNeed_Business
global NumNeed_Activity
global NumTotal_History
global NumTotal_Business
global NumTotal_Activity
global NumTotal_Mix

global point_count 

global ChoiceSet_History 
global ChoiceSet_Business 
global ChoiceSet_Activity 
global ChoiceSet_Mix 

global Info_Resident 
global Info_Tourist 
global Info_History
global Info_PropertyRights
global Info_DamageLevel 
global Info_CommercialStreet 

global DisMt 


% [2.2]
point_count=length(raw00);

ChoiceSet_History=num01'+1;
ChoiceSet_Business=num02'+1;
ChoiceSet_Activity=num03'+1;
ChoiceSet_Mix=num04'+1;

Info_Resident=num05;
for i = 1:length(Info_Resident)
    Info_Resident(i,1)=Info_Resident(i,1)+1;
end 

Info_Tourist=num06;
for i = 1:length(Info_Tourist)
    Info_Tourist(i,1)=Info_Tourist(i,1)+1;
end 

Info_History=num07;
for i = 1:length(Info_History)
    Info_History(i,1)=Info_History(i,1)+1;
end 

Info_PropertyRights=num08;
for i = 1:length(Info_PropertyRights)
    Info_PropertyRights(i,1)=Info_PropertyRights(i,1)+1;
end 

Info_DamageLevel=num09;
for i = 1:length(Info_DamageLevel)
    Info_DamageLevel(i,1)=Info_DamageLevel(i,1)+1;
end 

Info_CommercialStreet=num10;
for i = 1:length(Info_CommercialStreet)
    Info_CommercialStreet(i,1)=Info_CommercialStreet(i,1)+1;
end 

NumNeed_History=4; 
NumNeed_Business=12;
NumNeed_Activity=6;

NumTotal_History=length(num01); %9
NumTotal_Business=length(num02); %41
NumTotal_Activity=length(num03); %16
NumTotal_Mix=length(num04); %5

%% [3]Generation and Transformation of Feasible Solutions

% Function: Rand_FeasibleSolution_Binary,BinaryToIndex

%% [4]Graph-theory Model

%[4.1]
char_raw=char(raw00);
Adjacency_Matrix=zeros(point_count);
for i=1:point_count
    Adjacency_Matrix(i,:)=eval(char_raw(i,:));
end

%[4.2]
s=cellstr(strcat("v",int2str([1:point_count]')));
G=graph(Adjacency_Matrix,s,"upper");

%[4.3]
%h=plot(G,'EdgeLabel',G.Edges.Weight,'Layout',"force3");

%[4.4]
DisMt=distances(G);


%% [5]Objective Function

%[5.1]List of Objective Functions
%[(01)]ObjFuc_01 comprehensive layout equity for all catalyst element types
%[(02)]ObjFuc_02 independent layout equity for public-space catalyst elements
%[(03)]ObjFuc_03 degree of renewal difficulty
%[(04)]ObjFuc_04 renewal urgency
%[(05)]ObjFuc_05 historical value of historical catalyst elements
%[(06)]ObjFuc_06 average distance from historical catalyst elements to Liuhe Confucian Temple
%[(07)]ObjFuc_07 quantity of commercial catalyst elements along main commercial streets
%[(08)]ObjFuc_08 average distance from commercial catalyst elements to Liuhe Confucian Temple

%[(*)]Linear Weighting Function: ObjFuc_All

%[5.2]Weight Calculation via Coefficient of Variation Method

num_sample = 1000000;
testData = zeros(num_sample,8);

for i=1:num_sample
    n=randi([0, 4]);
    randTest = Rand_FeasibleSolution_Binary(n);
    IndexTest = BinaryToIndex(randTest,n);
    testData(i,1) = ObjFuc_01(IndexTest);
    testData(i,2) = ObjFuc_02(IndexTest);
    testData(i,3) = ObjFuc_03(IndexTest);
    testData(i,4) = ObjFuc_04(IndexTest);
    testData(i,5) = ObjFuc_05(IndexTest);
    testData(i,6) = ObjFuc_06(IndexTest);
    testData(i,7) = ObjFuc_07(IndexTest);
    testData(i,8) = ObjFuc_08(IndexTest);
end

max_testData = max(testData)
min_testData = min(testData)
cvWeight = CV_weight(testData)

n=randi([0, 4])
randTest = Rand_FeasibleSolution_Binary(n);
IndexTest = BinaryToIndex(randTest,n);
ObjFuc_All(IndexTest)
