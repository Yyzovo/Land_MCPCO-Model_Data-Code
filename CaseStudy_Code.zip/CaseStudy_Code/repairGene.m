function [repaired] = repairGene(child,ParalCombineMatrix)

global lenGene
lenPCM=length(ParalCombineMatrix);
repaired=zeros(1,lenGene);

newPCM=zeros(lenPCM,3);
newPCM(1,:)=[1,ParalCombineMatrix(1,1),ParalCombineMatrix(1,2)];

for i=2:lenPCM
    newPCM(i,1) = 1+sum(ParalCombineMatrix(1:i-1,1));
    newPCM(i,2) = newPCM(i,1)+ParalCombineMatrix(i,1)-1;
    newPCM(i,3) = ParalCombineMatrix(i,2);
end

for i=1:lenPCM
    geneSeg = child(newPCM(i,1):newPCM(i,2));
    needOnes = newPCM(i,3);
    numOnes = sum(geneSeg);

    if numOnes > needOnes
        onesPos = find(geneSeg);
        removeIdx = randperm(numOnes, numOnes - needOnes);
        geneSeg(onesPos(removeIdx)) = 0;
    end

    if numOnes < needOnes
        zerosPos = find(~geneSeg);
        addIdx = randperm(length(zerosPos), needOnes - numOnes);
        geneSeg(zerosPos(addIdx)) = 1;
    end
    repaired(newPCM(i,1):newPCM(i,2))=geneSeg;
end

end